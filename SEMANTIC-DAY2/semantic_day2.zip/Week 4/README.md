# Hướng dẫn chạy chương trình

## Cách chạy file
Thực hiện chạy file Make bằng cách chạy lệnh `./day 2/make`

Để chạy chương trình, bạn cần chạy tệp `run_kplc.bat` tại thư mục `./day 2`.

```sh
./day 2/run_kplc.bat
```

## Output

Output của chương trình sẽ được ghi vào file `test` với nội dung là:

```
output1.txt
output2.txt
output3.txt
output4.txt
output5.txt
output6.txt
```

## So sánh kết quả

Tệp `run_kplc.bat` đã so sánh output đầu ra với kết quả cho trước đã có.